package com.example.datepicker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    ImageButton ib;
    ConstraintLayout cl;
    Switch sw;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ib=findViewById(R.id.imageButton);
        cl=findViewById(R.id.Clayout);
        sw=findViewById(R.id.Aswitch);
        DatePicker dp=new DatePicker(this);
        cl.addView(dp);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    cl.removeView(dp);
                    ib.setEnabled(true);
                }
                else
                {
                    cl.addView(dp);
                    ib.setEnabled(false);
                }

            }
        });


    }
}